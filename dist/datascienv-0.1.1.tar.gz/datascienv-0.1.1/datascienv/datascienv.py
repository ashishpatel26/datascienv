def info():
    print("Welcome to Data Science Environment Module.")
    print("-------------------------------")
    print("Your Data Science Environment is Ready to use.")
    print("-------------------------------")